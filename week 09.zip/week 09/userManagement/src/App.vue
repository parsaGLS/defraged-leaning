<script setup lang="ts">
// import { RouterLink, RouterView } from 'vue-router'
import 'vuetify'
</script>

<template>
  <v-app>
  <br>
  <br>
  <br>

  <RouterView />



  </v-app>
</template>


