<script setup lang="ts">

import AddUser from "@/components/AddUser.vue";
import UserTable from "@/components/UserTable.vue";
</script>

<template>
<AddUser/>
  <UserTable/>
</template>

<style scoped>

</style>