<script setup  >
import {useUserTableStore} from "@/stores/UserTableStore";
const userTableStore=useUserTableStore();
</script>

<template >
  <v-table>
    <thead>
    <tr>
      <th class="text-left">
        Name
      </th>
      <th class="text-left">
        Age
      </th>
      <th class="text-left">
        Gender
      </th>
      <th class="text-left">
      Interest
    </th>
      <th class="text-left">
        Action
      </th>
    </tr>
    </thead>
    <tbody>
    <tr
        v-for="user in userTableStore.users"
        :key="user.name"
    >
      <td>{{ user.name }}</td>
      <td>{{ user.age }}</td>
      <td>{{ user.gender }}</td>
      <td>{{ user.interest }}</td>
      <td>

        <v-dialog v-model="userTableStore.dialog" max-width="600">
          <template v-slot:activator="{ props: activatorProps }">
            <v-btn
                class="bg-light-blue text-sm-h6"
                text="Edit"
                variant="tonal"
                v-bind="activatorProps"
                @click="userTableStore.prepareInputs(user.id)"
            ></v-btn>
          </template>


          <form @submit.prevent="userTableStore.editUser()">
            <v-card prepend-icon="mdi-account" title="User Profile">
              <v-card-text>
                <v-row dense>


                  <v-col cols="12" sm="6">
                    <v-text-field v-model="userTableStore.firstname" id="firstname" name="firstname" label="First name*" required></v-text-field>
                  </v-col>

                  <v-col cols="12" sm="6">
                    <v-text-field
                        v-model="userTableStore.lastname"
                        label="Last name*"
                        required
                    ></v-text-field>
                  </v-col>


                  <v-col cols="12" sm="6">
                    <v-text-field
                        v-model="userTableStore.age"
                        label="Age*"
                        required
                        type="number"
                    ></v-text-field>
                  </v-col>


                  <v-col cols="12" sm="6">
                    <v-autocomplete
                        v-model="userTableStore.gender"
                        :items="['Male', 'Female']"
                        label="Gender"
                        auto-select-first
                    ></v-autocomplete>
                  </v-col>


                  <!--          <v-col cols="12" sm="6">-->
                  <!--            <v-select-->
                  <!--                :items="['0-17', '18-29', '30-54', '54+']"-->
                  <!--                label="Age*"-->
                  <!--                required-->
                  <!--            ></v-select>-->
                  <!--          </v-col>-->

                  <v-col cols="12" sm="6">
                    <v-autocomplete
                        v-model="userTableStore.interest"
                        :items="['Skiing', 'Ice hockey', 'Soccer', 'Basketball', 'Hockey', 'Reading', 'Writing', 'Coding', 'Basejump']"
                        label="Interests"
                        multiple
                    ></v-autocomplete>
                  </v-col>
                </v-row>

                <small class="text-caption text-medium-emphasis"
                >*indicates required field</small
                >
              </v-card-text>

              <v-divider></v-divider>

              <v-card-actions>
                <v-spacer></v-spacer>

                <v-btn text="Close" variant="plain" @click="userTableStore.resetValue() "></v-btn>

                <v-btn
                    color="primary"
                    text="Save"
                    variant="tonal"
                    @click="userTableStore.dialog = false"
                    type="submit"
                ></v-btn>
              </v-card-actions>
            </v-card>
          </form>


        </v-dialog>



      </td>
    </tr>
    </tbody>
  </v-table>

</template>
