<script setup>
import 'vuetify';
import {useAddUserStore} from "@/stores/AddUserStore.js";

const addUserStore = useAddUserStore();
</script>

<template>
  <v-app-bar :elevation="10" rounded>
    <div class="text-h4 mx-5 ">User</div>
    <v-dialog v-model="addUserStore.dialog" max-width="600">
      <template v-slot:activator="{ props: activatorProps }">
        <v-btn
            class="bg-light-blue text-sm-h6"
            text="Create"
            variant="tonal"
            v-bind="activatorProps"
        ></v-btn>
      </template>


      <form @submit.prevent="addUserStore.addUser()">
        <v-card prepend-icon="mdi-account" title="User Profile">
          <v-card-text>
            <v-row dense>


              <v-col cols="12" sm="6">
                <v-text-field v-model="addUserStore.firstname" id="firstname" name="firstname" label="First name*"
                              required></v-text-field>
              </v-col>

              <v-col cols="12" sm="6">
                <v-text-field
                    v-model="addUserStore.lastname"
                    label="Last name*"
                    required
                ></v-text-field>
              </v-col>


              <v-col cols="12" sm="6">
                <v-text-field
                    v-model="addUserStore.age"
                    label="Age*"
                    required
                    type="number"
                ></v-text-field>
              </v-col>


              <v-col cols="12" sm="6">
                <v-autocomplete
                    v-model="addUserStore.gender"
                    :items="['Male', 'Female']"
                    label="Gender"
                    auto-select-first
                ></v-autocomplete>
              </v-col>


              <!--          <v-col cols="12" sm="6">-->
              <!--            <v-select-->
              <!--                :items="['0-17', '18-29', '30-54', '54+']"-->
              <!--                label="Age*"-->
              <!--                required-->
              <!--            ></v-select>-->
              <!--          </v-col>-->

              <v-col cols="12" sm="6">
                <v-autocomplete
                    v-model="addUserStore.interest"
                    :items="['Skiing', 'Ice hockey', 'Soccer', 'Basketball', 'Hockey', 'Reading', 'Writing', 'Coding', 'Basejump']"
                    label="Interests"
                    multiple
                ></v-autocomplete>
              </v-col>
            </v-row>

            <small class="text-caption text-medium-emphasis"
            >*indicates required field</small
            >
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-spacer></v-spacer>

            <v-btn text="Close" variant="plain" @click="addUserStore.resetValue() "></v-btn>

            <v-btn
                color="primary"
                text="Save"
                variant="tonal"
                @click="addUserStore.dialog = false"
                type="submit"
            ></v-btn>
          </v-card-actions>
        </v-card>
      </form>


    </v-dialog>


  </v-app-bar>

</template>

