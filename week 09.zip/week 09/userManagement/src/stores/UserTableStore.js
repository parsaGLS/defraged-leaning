import {defineStore} from "pinia";

export const useUserTableStore=defineStore("UserTableStore",{
    state:()=>{
        return {
            users:[],
            dialog:false,
            firstname:"test",
            lastname:"",
            age:"",
            gender:"",
            interest:[],
            id:1
        }
    },
    actions:{
        resetValue(){
            this.firstname="";
            this.lastname="";
            this.age="";
            this.gender="";
            this.interest=[];
            this.dialog=false;
            this.id=1;

        },
        prepareInputs(id){
            let editUser = this.users.findIndex((value)=>{
                return value.id===id
            });
            this.id=editUser
            this.firstname=this.users[editUser].name.split(" ")[0];
            this.lastname=this.users[editUser].name.split(" ")[1];
            this.age=this.users[editUser].age;
            this.gender=this.users[editUser].gender;
            this.interest=this.users[editUser].interest.split(',');
        },
        editUser(){
            console.log(this.id);
            this.users[this.id]={
                id: this.id,
                name: this.firstname + " " + this.lastname,
                age: this.age,
                gender: this.gender,
                interest: this.interest.toString(),
            };
            this.resetValue();
        }
    }

});