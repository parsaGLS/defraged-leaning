import {useUserTableStore} from "@/stores/UserTableStore.js";
import {defineStore} from "pinia";

export const useAddUserStore = defineStore("AddUserStore", {
    state: () => {
        return {
            dialog: false,
            firstname: "",
            lastname: "",
            age: "",
            gender: "",
            interest: [],
            id: 1
        }
    },
    actions: {
        addUser() {
            const newUser = {
                id: this.id,
                name: this.firstname + " " + this.lastname,
                age: this.age,
                gender: this.gender,
                interest: this.interest.toString()
            }

            const userTable = useUserTableStore();
            userTable.users.push(newUser);
            // console.log(userTable.users);
            this.id++;
            this.resetValue();

        },
        resetValue() {
            this.firstname = "";
            this.lastname = "";
            this.age = "";
            this.gender = "";
            this.interest = [];
            this.dialog = false;

        },


    }
});